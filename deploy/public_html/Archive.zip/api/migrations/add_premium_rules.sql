ALTER TABLE site_content ADD COLUMN premium_rules TEXT DEFAULT NULL;
