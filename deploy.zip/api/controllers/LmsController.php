<?php
// backend/controllers/LmsController.php
include_once './config/database.php';
include_once './utils/Helper.php';

class LmsController
{
    private $db;
    private $conn;

    public function __construct()
    {
        $this->db = new Database();
        $this->conn = $this->db->getConnection();
        $this->ensureTablesExist();
    }

    private function ensureTablesExist() {
        try {
            $this->conn->exec("
                CREATE TABLE IF NOT EXISTS lms_user_progress (
                    id VARCHAR(36) PRIMARY KEY,
                    user_id VARCHAR(36) NOT NULL,
                    event_id VARCHAR(36) NOT NULL,
                    item_type VARCHAR(20) NOT NULL,
                    item_id VARCHAR(36) NOT NULL,
                    is_completed TINYINT(1) DEFAULT 0,
                    completed_at TIMESTAMP NULL,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    UNIQUE KEY unique_user_item (user_id, item_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            ");
            
            $this->conn->exec("
                CREATE TABLE IF NOT EXISTS lms_assignment_submissions (
                    id VARCHAR(36) PRIMARY KEY,
                    assignment_id VARCHAR(36) NOT NULL,
                    user_id VARCHAR(36) NOT NULL,
                    content_url TEXT,
                    text_content TEXT,
                    score DECIMAL(5,2) DEFAULT NULL,
                    feedback TEXT,
                    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    graded_at TIMESTAMP NULL,
                    UNIQUE KEY unique_submission (assignment_id, user_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            ");

            $this->conn->exec("
                CREATE TABLE IF NOT EXISTS lms_quiz_attempts (
                    id VARCHAR(36) PRIMARY KEY,
                    quiz_id VARCHAR(36) NOT NULL,
                    user_id VARCHAR(36) NOT NULL,
                    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    finished_at TIMESTAMP NULL,
                    answers JSON DEFAULT NULL,
                    total_score DECIMAL(5,2) DEFAULT 0,
                    is_passed TINYINT(1) DEFAULT 0
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            ");
        } catch (\PDOException $e) {
            // Silently ignore if lacking permissions, etc.
        }
    }

    // ==========================================
    // TOPICS
    // ==========================================

    public function getTopicsByEvent($eventId)
    {
        $query = "SELECT * FROM lms_topics WHERE event_id = :event_id ORDER BY order_num ASC";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':event_id', $eventId);
        $stmt->execute();
        
        $topics = $stmt->fetchAll(PDO::FETCH_ASSOC);
        // Cast types
        foreach ($topics as &$topic) {
            $topic['order_num'] = (int)$topic['order_num'];
        }
        return json_encode($topics);
    }

    public function createTopic($data, $userId, $userName)
    {
        try {
            $id = Helper::uuid();
            $query = "INSERT INTO lms_topics (id, event_id, title, order_num, created_at) 
                      VALUES (:id, :event_id, :title, :order_num, NOW())";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':id', $id);
            $stmt->bindParam(':event_id', $data['event_id']);
            $stmt->bindParam(':title', $data['title']);
            $orderNum = isset($data['order_num']) ? (int)$data['order_num'] : 0;
            $stmt->bindParam(':order_num', $orderNum, PDO::PARAM_INT);
            
            if ($stmt->execute()) {
                // Fetch the created record
                $stmtGet = $this->conn->prepare("SELECT * FROM lms_topics WHERE id = :id");
                $stmtGet->bindParam(':id', $id);
                $stmtGet->execute();
                $topic = $stmtGet->fetch(PDO::FETCH_ASSOC);
                
                Helper::log($this->conn, $userId, $userName, 'CREATE_LMS_TOPIC', $data['title'] . " (Event: {$data['event_id']})");
                return json_encode(["message" => "Topic created", "data" => $topic]);
            }
            http_response_code(500);
            return json_encode(["message" => "Failed to create topic"]);
        } catch (\Throwable $e) {
            http_response_code(500);
            return json_encode(["message" => "Error: " . $e->getMessage()]);
        }
    }

    public function updateTopic($id, $data, $userId, $userName)
    {
        try {
            $query = "UPDATE lms_topics SET title = :title, order_num = :order_num WHERE id = :id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':id', $id);
            $stmt->bindParam(':title', $data['title']);
            $orderNum = isset($data['order_num']) ? (int)$data['order_num'] : 0;
            $stmt->bindParam(':order_num', $orderNum, PDO::PARAM_INT);

            if ($stmt->execute()) {
                Helper::log($this->conn, $userId, $userName, 'UPDATE_LMS_TOPIC', $data['title']);
                
                // Fetch updated
                $stmtGet = $this->conn->prepare("SELECT * FROM lms_topics WHERE id = :id");
                $stmtGet->bindParam(':id', $id);
                $stmtGet->execute();
                $topic = $stmtGet->fetch(PDO::FETCH_ASSOC);
                
                return json_encode(["message" => "Topic updated", "data" => $topic]);
            }
            http_response_code(500);
            return json_encode(["message" => "Failed to update topic"]);
        } catch (\Throwable $e) {
            http_response_code(500);
            return json_encode(["message" => "Error: " . $e->getMessage()]);
        }
    }

    public function deleteTopic($id, $userId, $userName)
    {
        try {
            // Get title for logging
            $title = "Unknown";
            $stmtGet = $this->conn->prepare("SELECT title FROM lms_topics WHERE id = :id");
            $stmtGet->bindParam(':id', $id);
            $stmtGet->execute();
            if ($row = $stmtGet->fetch(PDO::FETCH_ASSOC)) {
                $title = $row['title'];
            }

            // Also delete associated materials (handled by DB cascade ideally, but let's be explicit if not)
            $stmtDelMat = $this->conn->prepare("DELETE FROM lms_materials WHERE topic_id = :id");
            $stmtDelMat->bindParam(':id', $id);
            $stmtDelMat->execute();

            $query = "DELETE FROM lms_topics WHERE id = :id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':id', $id);
            
            if ($stmt->execute()) {
                Helper::log($this->conn, $userId, $userName, 'DELETE_LMS_TOPIC', $title);
                return json_encode(["message" => "Topic deleted"]);
            }
            http_response_code(500);
            return json_encode(["message" => "Failed to delete topic"]);
        } catch (\Throwable $e) {
            http_response_code(500);
            return json_encode(["message" => "Error: " . $e->getMessage()]);
        }
    }
    public function reorderTopics($items, $userId, $userName)
    {
        try {
            $this->conn->beginTransaction();
            $stmt = $this->conn->prepare("UPDATE lms_topics SET order_num = :order_num WHERE id = :id");
            foreach ($items as $item) {
                $stmt->execute([
                    ':id' => $item['id'],
                    ':order_num' => (int)$item['order_num']
                ]);
            }
            $this->conn->commit();
            
            Helper::log($this->conn, $userId, $userName, 'REORDER_LMS_TOPICS', 'Reordered topics');
            return json_encode(["message" => "Topics reordered successfully"]);
        } catch (\Throwable $e) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            http_response_code(500);
            return json_encode(["message" => "Error: " . $e->getMessage()]);
        }
    }

    // ==========================================
    // MATERIALS
    // ==========================================

    public function getMaterialsByTopic($topicId)
    {
        $query = "SELECT * FROM lms_materials WHERE topic_id = :topic_id ORDER BY order_num ASC";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':topic_id', $topicId);
        $stmt->execute();
        
        $materials = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($materials as &$mat) {
            $mat['order_num'] = (int)$mat['order_num'];
            $mat['duration'] = (int)$mat['duration'];
        }
        return json_encode($materials);
    }

    public function createMaterial($data, $userId, $userName)
    {
        try {
            $id = Helper::uuid();
            $query = "INSERT INTO lms_materials (id, topic_id, title, type, content, url, duration, order_num, available_at, deadline_at, created_at) 
                      VALUES (:id, :topic_id, :title, :type, :content, :url, :duration, :order_num, :available_at, :deadline_at, NOW())";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':id', $id);
            $stmt->bindParam(':topic_id', $data['topic_id']);
            $stmt->bindParam(':title', $data['title']);
            $stmt->bindParam(':type', $data['type']);
            $content = $data['content'] ?? null;
            $stmt->bindParam(':content', $content);
            $url = $data['url'] ?? null;
            $stmt->bindParam(':url', $url);
            $duration = isset($data['duration']) ? (int)$data['duration'] : 0;
            $stmt->bindParam(':duration', $duration, PDO::PARAM_INT);
            $orderNum = isset($data['order_num']) ? (int)$data['order_num'] : 0;
            $stmt->bindParam(':order_num', $orderNum, PDO::PARAM_INT);
            
            $availableAt = !empty($data['available_at']) ? $data['available_at'] : null;
            $stmt->bindParam(':available_at', $availableAt);
            $deadlineAt = !empty($data['deadline_at']) ? $data['deadline_at'] : null;
            $stmt->bindParam(':deadline_at', $deadlineAt);
            
            if ($stmt->execute()) {
                $stmtGet = $this->conn->prepare("SELECT * FROM lms_materials WHERE id = :id");
                $stmtGet->bindParam(':id', $id);
                $stmtGet->execute();
                $material = $stmtGet->fetch(PDO::FETCH_ASSOC);

                Helper::log($this->conn, $userId, $userName, 'CREATE_LMS_MATERIAL', $data['title']);
                return json_encode(["message" => "Material created", "data" => $material]);
            }
            http_response_code(500);
            return json_encode(["message" => "Failed to create material"]);
        } catch (\Throwable $e) {
            http_response_code(500);
            return json_encode(["message" => "Error: " . $e->getMessage()]);
        }
    }

    public function updateMaterial($id, $data, $userId, $userName)
    {
        try {
            $query = "UPDATE lms_materials SET 
                        title = :title, 
                        type = :type,
                        content = :content,
                        url = :url,
                        duration = :duration,
                        order_num = :order_num,
                        available_at = :available_at,
                        deadline_at = :deadline_at
                      WHERE id = :id";
                      
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':id', $id);
            $stmt->bindParam(':title', $data['title']);
            $stmt->bindParam(':type', $data['type']);
            $content = $data['content'] ?? null;
            $stmt->bindParam(':content', $content);
            $url = $data['url'] ?? null;
            $stmt->bindParam(':url', $url);
            $duration = isset($data['duration']) ? (int)$data['duration'] : 0;
            $stmt->bindParam(':duration', $duration, PDO::PARAM_INT);
            $orderNum = isset($data['order_num']) ? (int)$data['order_num'] : 0;
            $stmt->bindParam(':order_num', $orderNum, PDO::PARAM_INT);
            
            $availableAt = !empty($data['available_at']) ? $data['available_at'] : null;
            $stmt->bindParam(':available_at', $availableAt);
            $deadlineAt = !empty($data['deadline_at']) ? $data['deadline_at'] : null;
            $stmt->bindParam(':deadline_at', $deadlineAt);

            if ($stmt->execute()) {
                Helper::log($this->conn, $userId, $userName, 'UPDATE_LMS_MATERIAL', $data['title']);
                
                $stmtGet = $this->conn->prepare("SELECT * FROM lms_materials WHERE id = :id");
                $stmtGet->bindParam(':id', $id);
                $stmtGet->execute();
                $material = $stmtGet->fetch(PDO::FETCH_ASSOC);

                return json_encode(["message" => "Material updated", "data" => $material]);
            }
            http_response_code(500);
            return json_encode(["message" => "Failed to update material"]);
        } catch (\Throwable $e) {
            http_response_code(500);
            return json_encode(["message" => "Error: " . $e->getMessage()]);
        }
    }

    public function deleteMaterial($id, $userId, $userName)
    {
        try {
            // Get title for logging
            $title = "Unknown";
            $stmtGet = $this->conn->prepare("SELECT title FROM lms_materials WHERE id = :id");
            $stmtGet->bindParam(':id', $id);
            $stmtGet->execute();
            if ($row = $stmtGet->fetch(PDO::FETCH_ASSOC)) {
                $title = $row['title'];
            }

            $query = "DELETE FROM lms_materials WHERE id = :id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':id', $id);
            
            if ($stmt->execute()) {
                Helper::log($this->conn, $userId, $userName, 'DELETE_LMS_MATERIAL', $title);
                return json_encode(["message" => "Material deleted"]);
            }
            http_response_code(500);
            return json_encode(["message" => "Failed to delete material"]);
        } catch (\Throwable $e) {
            http_response_code(500);
            return json_encode(["message" => "Error: " . $e->getMessage()]);
        }
    }
    public function reorderMaterials($items, $userId, $userName)
    {
        try {
            $this->conn->beginTransaction();
            $stmt = $this->conn->prepare("UPDATE lms_materials SET order_num = :order_num WHERE id = :id");
            foreach ($items as $item) {
                $stmt->execute([
                    ':id' => $item['id'],
                    ':order_num' => (int)$item['order_num']
                ]);
            }
            $this->conn->commit();
            
            Helper::log($this->conn, $userId, $userName, 'REORDER_LMS_MATERIALS', 'Reordered materials');
            return json_encode(["message" => "Materials reordered successfully"]);
        } catch (\Throwable $e) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            http_response_code(500);
            return json_encode(["message" => "Error: " . $e->getMessage()]);
        }
    }

    // ==========================================
    // QUIZZES
    // ==========================================

    public function getQuizByMaterialId($materialId)
    {
        try {
            // Check if quiz exists for this topic/material
            // Assuming material has type='quiz', and the quiz's `id` is linked to material's `id` or topic
            // Wait, in lms_schema.sql.md, lms_quizzes has `id`, `topic_id`.
            // But how do we map a material of type quiz to lms_quizzes? 
            // Often, material.id == quiz.id or quiz has `material_id`. 
            // In the schema: CREATE TABLE lms_quizzes (id, topic_id, title...)
            // Since we navigate to `/admin/events/:eventId/lms/quiz/:materialId`, we can assume `lms_quizzes.id` = `lms_materials.id`
            $query = "SELECT * FROM lms_quizzes WHERE id = :id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':id', $materialId);
            $stmt->execute();
            $quiz = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$quiz) {
                return json_encode(null);
            }

            // Fetch questions
            $qQuery = "SELECT * FROM lms_quiz_questions WHERE quiz_id = :quiz_id ORDER BY order_num ASC";
            $qStmt = $this->conn->prepare($qQuery);
            $qStmt->bindParam(':quiz_id', $quiz['id']);
            $qStmt->execute();
            $questions = $qStmt->fetchAll(PDO::FETCH_ASSOC);

            // Fetch options for each question
            foreach ($questions as &$question) {
                $oQuery = "SELECT * FROM lms_quiz_options WHERE question_id = :question_id";
                $oStmt = $this->conn->prepare($oQuery);
                $oStmt->bindParam(':question_id', $question['id']);
                $oStmt->execute();
                $options = $oStmt->fetchAll(PDO::FETCH_ASSOC);
                
                // Convert is_correct to boolean for frontend
                foreach ($options as &$opt) {
                    $opt['is_correct'] = (bool)$opt['is_correct'];
                }
                $question['options'] = $options;
            }

            $quiz['questions'] = $questions;
            return json_encode($quiz);
        } catch (\Throwable $e) {
            http_response_code(500);
            return json_encode(["message" => "Error: " . $e->getMessage()]);
        }
    }

    public function saveQuiz($data, $userId, $userName)
    {
        try {
            $this->conn->beginTransaction();

            $quizId = $data['id']; // This is the materialId
            $topicId = $data['topic_id'] ?? '';
            $title = $data['title'] ?? 'Quiz';
            $description = $data['description'] ?? '';
            $duration = isset($data['duration_minutes']) ? (int)$data['duration_minutes'] : 0;
            $passingScore = isset($data['passing_score']) ? (float)$data['passing_score'] : 70;
            $maxAttempts = isset($data['max_attempts']) ? (int)$data['max_attempts'] : 1;

            // Check if quiz exists
            $stmtCheck = $this->conn->prepare("SELECT id FROM lms_quizzes WHERE id = :id");
            $stmtCheck->bindParam(':id', $quizId);
            $stmtCheck->execute();

            if ($stmtCheck->rowCount() > 0) {
                // Update
                $q = "UPDATE lms_quizzes SET title = :title, description = :description, duration_minutes = :duration_minutes, passing_score = :passing_score, max_attempts = :max_attempts WHERE id = :id";
                $s = $this->conn->prepare($q);
            } else {
                // Insert
                $q = "INSERT INTO lms_quizzes (id, topic_id, title, description, duration_minutes, passing_score, max_attempts) VALUES (:id, :topic_id, :title, :description, :duration_minutes, :passing_score, :max_attempts)";
                $s = $this->conn->prepare($q);
                $s->bindParam(':topic_id', $topicId);
            }

            $s->bindParam(':id', $quizId);
            $s->bindParam(':title', $title);
            $s->bindParam(':description', $description);
            $s->bindParam(':duration_minutes', $duration, PDO::PARAM_INT);
            $s->bindParam(':passing_score', $passingScore);
            $s->bindParam(':max_attempts', $maxAttempts, PDO::PARAM_INT);
            $s->execute();

            // Clear old questions & options (simpler for updates)
            // Options will cascade or we delete them explicitly
            $stmtGetOldQs = $this->conn->prepare("SELECT id FROM lms_quiz_questions WHERE quiz_id = :quiz_id");
            $stmtGetOldQs->bindParam(':quiz_id', $quizId);
            $stmtGetOldQs->execute();
            $oldQs = $stmtGetOldQs->fetchAll(PDO::FETCH_ASSOC);

            foreach ($oldQs as $oldQ) {
                $delOpt = $this->conn->prepare("DELETE FROM lms_quiz_options WHERE question_id = :q_id");
                $delOpt->bindParam(':q_id', $oldQ['id']);
                $delOpt->execute();
            }

            $delQ = $this->conn->prepare("DELETE FROM lms_quiz_questions WHERE quiz_id = :quiz_id");
            $delQ->bindParam(':quiz_id', $quizId);
            $delQ->execute();

            // Insert new questions
            $questions = $data['questions'] ?? [];
            foreach ($questions as $index => $qData) {
                $qId = Helper::uuid();
                $qText = $qData['text'] ?? '';
                $qType = $qData['type'] ?? 'multiple_choice';
                $qPoints = isset($qData['points']) ? (float)$qData['points'] : 1;
                
                $iQ = "INSERT INTO lms_quiz_questions (id, quiz_id, question_text, question_type, points, order_num) VALUES (:id, :quiz_id, :qtext, :qtype, :points, :order_num)";
                $siQ = $this->conn->prepare($iQ);
                $siQ->bindParam(':id', $qId);
                $siQ->bindParam(':quiz_id', $quizId);
                $siQ->bindParam(':qtext', $qText);
                $siQ->bindParam(':qtype', $qType);
                $siQ->bindParam(':points', $qPoints);
                $siQ->bindParam(':order_num', $index, PDO::PARAM_INT);
                $siQ->execute();

                // Insert options
                $options = $qData['options'] ?? [];
                foreach ($options as $optData) {
                    $oId = Helper::uuid();
                    $oText = $optData['text'] ?? '';
                    $oCorrect = !empty($optData['is_correct']) ? 1 : 0;
                    
                    $iO = "INSERT INTO lms_quiz_options (id, question_id, option_text, is_correct) VALUES (:id, :qid, :otext, :is_correct)";
                    $siO = $this->conn->prepare($iO);
                    $siO->bindParam(':id', $oId);
                    $siO->bindParam(':qid', $qId);
                    $siO->bindParam(':otext', $oText);
                    $siO->bindParam(':is_correct', $oCorrect, PDO::PARAM_INT);
                    $siO->execute();
                }
            }

            $this->conn->commit();
            
            Helper::log($this->conn, $userId, $userName, 'SAVE_LMS_QUIZ', $title);
            return json_encode(["message" => "Quiz saved successfully"]);

        } catch (\Throwable $e) {
            $this->conn->rollBack();
            http_response_code(500);
            return json_encode(["message" => "Error: " . $e->getMessage()]);
        }
    }

    public function getAssignmentSubmission($assignmentId, $userId) {
        try {
            $query = "SELECT * FROM lms_assignment_submissions WHERE assignment_id = :aid AND user_id = :uid LIMIT 1";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':aid', $assignmentId);
            $stmt->bindParam(':uid', $userId);
            $stmt->execute();
            return json_encode($stmt->fetch(\PDO::FETCH_ASSOC) ?: null);
        } catch (\PDOException $e) {
            http_response_code(500);
            return json_encode(["message" => "Database error: " . $e->getMessage()]);
        }
    }

    public function submitAssignment($data, $userId, $userName) {
        if (!$userId) {
            http_response_code(401);
            return json_encode(["message" => "Unauthorized"]);
        }
        try {
            $assignmentId = $data['assignment_id'] ?? '';
            $contentUrl = $data['content_url'] ?? '';
            $textContent = $data['text_content'] ?? '';

            $chk = $this->conn->prepare("SELECT id FROM lms_assignment_submissions WHERE assignment_id = :aid AND user_id = :uid LIMIT 1");
            $chk->execute([':aid' => $assignmentId, ':uid' => $userId]);
            $existing = $chk->fetch();

            if ($existing) {
                $q = "UPDATE lms_assignment_submissions SET content_url = :url, text_content = :txt, submitted_at = NOW() WHERE id = :id";
                $s = $this->conn->prepare($q);
                $s->execute([':url' => $contentUrl, ':txt' => $textContent, ':id' => $existing['id']]);
                $id = $existing['id'];
            } else {
                $id = Helper::uuid();
                $q = "INSERT INTO lms_assignment_submissions (id, assignment_id, user_id, content_url, text_content, submitted_at) VALUES (:id, :aid, :uid, :url, :txt, NOW())";
                $s = $this->conn->prepare($q);
                $s->execute([':id' => $id, ':aid' => $assignmentId, ':uid' => $userId, ':url' => $contentUrl, ':txt' => $textContent]);
            }
            $this->_autoMarkProgress($assignmentId, 'assignment', $userId);
            return json_encode(["message" => "Berhasil dikumpulkan", "id" => $id]);
        } catch (\PDOException $e) {
            http_response_code(500);
            return json_encode(["message" => "Database error: " . $e->getMessage()]);
        }
    }

    public function getQuizAttempts($quizId, $userId) {
        try {
            $q = "SELECT * FROM lms_quiz_attempts WHERE quiz_id = :qid AND user_id = :uid ORDER BY started_at DESC";
            $stmt = $this->conn->prepare($q);
            $stmt->execute([':qid' => $quizId, ':uid' => $userId]);
            return json_encode($stmt->fetchAll(\PDO::FETCH_ASSOC));
        } catch (\PDOException $e) {
            http_response_code(500);
            return json_encode(["message" => "Database error: " . $e->getMessage()]);
        }
    }

    public function submitQuizAttempt($data, $userId, $userName) {
        if (!$userId) {
            http_response_code(401);
            return json_encode(["message" => "Unauthorized"]);
        }
        try {
            $this->conn->beginTransaction();
            $quizId = $data['quiz_id'] ?? '';
            $answers = $data['answers'] ?? [];
            
            $stmt = $this->conn->prepare("SELECT * FROM lms_quizzes WHERE id = :id");
            $stmt->execute([':id' => $quizId]);
            $quiz = $stmt->fetch();
            if (!$quiz) throw new \Exception("Quiz not found");
            
            $qStmt = $this->conn->prepare("SELECT * FROM lms_quiz_questions WHERE quiz_id = :qid");
            $qStmt->execute([':qid' => $quizId]);
            $questions = $qStmt->fetchAll(\PDO::FETCH_ASSOC);

            $oStmt = $this->conn->prepare("SELECT * FROM lms_quiz_options WHERE question_id IN (SELECT id FROM lms_quiz_questions WHERE quiz_id = :qid)");
            $oStmt->execute([':qid' => $quizId]);
            $options = $oStmt->fetchAll(\PDO::FETCH_ASSOC);
            
            $totalPoints = 0;
            $earnedPoints = 0;
            $processedAnswers = [];
            
            foreach ($questions as $q) {
                $p = (float)($q['points'] ?? 1);
                $totalPoints += $p;
                
                $selectedOptIds = $answers[$q['id']] ?? null;
                $isCorrect = 0;
                $pointsEarned = 0;
                
                if (($q['question_type'] ?? '') === 'multiple_choice' && is_array($selectedOptIds)) {
                    $correctOptionIds = [];
                    foreach ($options as $opt) {
                        if ($opt['question_id'] === $q['id'] && $opt['is_correct']) {
                            $correctOptionIds[] = $opt['id'];
                        }
                    }
                    if (count($selectedOptIds) === count($correctOptionIds) && count(array_diff($selectedOptIds, $correctOptionIds)) === 0 && count(array_diff($correctOptionIds, $selectedOptIds)) === 0) {
                        $isCorrect = 1;
                        $pointsEarned = $p;
                        $earnedPoints += $p;
                    }
                    $selectedOptIdStr = json_encode($selectedOptIds);
                } else {
                    $selectedOptIdStr = is_array($selectedOptIds) ? json_encode($selectedOptIds) : $selectedOptIds;
                    foreach ($options as $opt) {
                        if ($opt['question_id'] === $q['id'] && $opt['is_correct']) {
                            if ($selectedOptIds === $opt['id']) {
                                $isCorrect = 1;
                                $pointsEarned = $p;
                                $earnedPoints += $p;
                            }
                            break;
                        }
                    }
                }
                
                $processedAnswers[] = [
                    'q_id' => $q['id'],
                    'o_id' => $selectedOptIdStr,
                    'is_correct' => $isCorrect,
                    'points_earned' => $pointsEarned
                ];
            }
            
            $score = $totalPoints > 0 ? round(($earnedPoints / $totalPoints) * 100) : 0;
            
            // Check if late (deadline passed)
            $stmtMat = $this->conn->prepare("SELECT deadline_at FROM lms_materials WHERE id = :id");
            $stmtMat->execute([':id' => $quizId]);
            $material = $stmtMat->fetch();
            $isLate = false;
            if ($material && !empty($material['deadline_at']) && strtotime($material['deadline_at']) < time()) {
                $isLate = true;
                $score = max(0, $score - 10); // Deduct 10 points for late submission, min score 0
            }

            $isPassed = $score >= (float)$quiz['passing_score'] ? 1 : 0;
            
            $attemptId = Helper::uuid();
            $insAtt = $this->conn->prepare("INSERT INTO lms_quiz_attempts (id, user_id, quiz_id, status, finished_at, total_score, is_passed) VALUES (:id, :uid, :qid, 'completed', NOW(), :score, :passed)");
            $insAtt->execute([
                ':id' => $attemptId,
                ':uid' => $userId,
                ':qid' => $quizId,
                ':score' => $score,
                ':passed' => $isPassed
            ]);
            
            $insAns = $this->conn->prepare("INSERT INTO lms_quiz_answers (id, attempt_id, question_id, selected_option_id, is_correct, score_awarded) VALUES (:id, :aid, :qid, :oid, :is_correct, :score_awarded)");
            foreach ($processedAnswers as $pa) {
                $insAns->execute([
                    ':id' => Helper::uuid(),
                    ':aid' => $attemptId,
                    ':qid' => $pa['q_id'],
                    ':oid' => $pa['o_id'],
                    ':is_correct' => $pa['is_correct'],
                    ':score_awarded' => $pa['points_earned']
                ]);
            }
            
            $this->_autoMarkProgress($quizId, 'quiz', $userId);

            $this->conn->commit();
            return json_encode([
                "message" => "Berhasil disimpan",
                "score" => $score,
                "earned_points" => $earnedPoints,
                "total_points" => $totalPoints,
                "is_passed" => $isPassed
            ]);
        } catch (\Throwable $e) {
            $this->conn->rollBack();
            http_response_code(500);
            return json_encode(["message" => "Error: " . $e->getMessage()]);
        }
    }

    public function getAllAssignmentSubmissions($assignmentId) {
        try {
            $query = "SELECT s.*, p.nama as user_name, m.deadline_at 
                      FROM lms_assignment_submissions s 
                      LEFT JOIN profiles p ON s.user_id = p.id 
                      LEFT JOIN lms_materials m ON s.assignment_id = m.id
                      WHERE s.assignment_id = :aid 
                      ORDER BY s.submitted_at DESC";
            $stmt = $this->conn->prepare($query);
            $stmt->execute([':aid' => $assignmentId]);
            return json_encode($stmt->fetchAll(\PDO::FETCH_ASSOC));
        } catch (\PDOException $e) {
            http_response_code(500);
            return json_encode(["message" => "Database error: " . $e->getMessage()]);
        }
    }

    public function gradeAssignment($data, $graderId) {
        if (!$graderId) {
            http_response_code(401);
            return json_encode(["message" => "Unauthorized"]);
        }
        try {
            $submissionId = $data['submission_id'] ?? '';
            $score = $data['score'] ?? null;
            $feedback = $data['feedback'] ?? '';
            
            $q = "UPDATE lms_assignment_submissions 
                  SET score = :score, feedback = :feedback, graded_at = NOW(), graded_by = :graderId 
                  WHERE id = :id";
            $stmt = $this->conn->prepare($q);
            $stmt->execute([
                ':score' => $score !== '' ? (float)$score : null,
                ':feedback' => $feedback,
                ':graderId' => $graderId,
                ':id' => $submissionId
            ]);
            
            return json_encode(["message" => "Penilaian berhasil disimpan"]);
        } catch (\PDOException $e) {
            http_response_code(500);
            return json_encode(["message" => "Database error: " . $e->getMessage()]);
        }
    }

    public function getAllQuizAttempts($quizId) {
        try {
            $query = "SELECT a.*, p.nama as user_name 
                      FROM lms_quiz_attempts a 
                      LEFT JOIN profiles p ON a.user_id = p.id 
                      WHERE a.quiz_id = :qid 
                      ORDER BY a.total_score DESC, a.started_at DESC";
            $stmt = $this->conn->prepare($query);
            $stmt->execute([':qid' => $quizId]);
            $attempts = $stmt->fetchAll(\PDO::FETCH_ASSOC);

            $bestAttempts = [];
            $seenUsers = [];
            foreach ($attempts as $attempt) {
                if (!isset($seenUsers[$attempt['user_id']])) {
                    $bestAttempts[] = $attempt;
                    $seenUsers[$attempt['user_id']] = true;
                }
            }

            return json_encode($bestAttempts);
        } catch (\PDOException $e) {
            http_response_code(500);
            return json_encode(["message" => "Database error: " . $e->getMessage()]);
        }
    }

    public function getQuizDetailedResults($quizId) {
        try {
            // 1. Get Questions
            $qStmt = $this->conn->prepare("
                SELECT id, question_text, question_type, points, order_num 
                FROM lms_quiz_questions 
                WHERE quiz_id = :qid 
                ORDER BY order_num, id
            ");
            $qStmt->execute([':qid' => $quizId]);
            $questions = $qStmt->fetchAll(\PDO::FETCH_ASSOC);

            // 2. Get Best Attempts
            $query = "SELECT a.*, p.nama as user_name, u.email as user_email
                      FROM lms_quiz_attempts a 
                      LEFT JOIN profiles p ON a.user_id = p.id 
                      LEFT JOIN users u ON a.user_id = u.id
                      WHERE a.quiz_id = :qid 
                      ORDER BY a.total_score DESC, a.started_at DESC";
            $stmt = $this->conn->prepare($query);
            $stmt->execute([':qid' => $quizId]);
            $allAttempts = $stmt->fetchAll(\PDO::FETCH_ASSOC);

            $bestAttempts = [];
            $seenUsers = [];
            $attemptIds = [];
            foreach ($allAttempts as $attempt) {
                if (!isset($seenUsers[$attempt['user_id']])) {
                    $bestAttempts[] = $attempt;
                    $seenUsers[$attempt['user_id']] = true;
                    $attemptIds[] = $attempt['id'];
                }
            }

            // 3. Get Answers for these attempts
            $answersByAttempt = [];
            if (count($attemptIds) > 0) {
                $inQuery = implode(',', array_fill(0, count($attemptIds), '?'));
                $ansStmt = $this->conn->prepare("
                    SELECT attempt_id, question_id, is_correct, score_awarded 
                    FROM lms_quiz_answers 
                    WHERE attempt_id IN ($inQuery)
                ");
                $ansStmt->execute($attemptIds);
                $answers = $ansStmt->fetchAll(\PDO::FETCH_ASSOC);

                foreach ($answers as $ans) {
                    if (!isset($answersByAttempt[$ans['attempt_id']])) {
                        $answersByAttempt[$ans['attempt_id']] = [];
                    }
                    $answersByAttempt[$ans['attempt_id']][$ans['question_id']] = [
                        'is_correct' => $ans['is_correct'],
                        'score_awarded' => $ans['score_awarded']
                    ];
                }
            }

            // 4. Merge answers into attempts
            foreach ($bestAttempts as &$attempt) {
                $attempt['answers'] = $answersByAttempt[$attempt['id']] ?? (object)[];
            }

            return json_encode([
                "questions" => $questions,
                "attempts" => $bestAttempts
            ]);
        } catch (\PDOException $e) {
            http_response_code(500);
            return json_encode(["message" => "Database error: " . $e->getMessage()]);
        }
    }

    public function deleteQuizAttempt($attemptId) {
        try {
            $this->conn->beginTransaction();
            $stmt = $this->conn->prepare("DELETE FROM lms_quiz_answers WHERE attempt_id = :id");
            $stmt->execute([':id' => $attemptId]);
            
            $stmt = $this->conn->prepare("DELETE FROM lms_quiz_attempts WHERE id = :id");
            $stmt->execute([':id' => $attemptId]);
            
            $this->conn->commit();
            return json_encode(["message" => "Attempt deleted successfully"]);
        } catch (\PDOException $e) {
            $this->conn->rollBack();
            http_response_code(500);
            return json_encode(["message" => "Database error: " . $e->getMessage()]);
        }
    }

    public function getQuizAttemptDetails($attemptId) {
        try {
            $stmt = $this->conn->prepare("SELECT a.*, p.nama as user_name FROM lms_quiz_attempts a JOIN profiles p ON a.user_id = p.id WHERE a.id = :id");
            $stmt->execute([':id' => $attemptId]);
            $attempt = $stmt->fetch(\PDO::FETCH_ASSOC);
            if (!$attempt) throw new \Exception("Attempt not found");
            
            $qStmt = $this->conn->prepare("
                SELECT q.id as question_id, q.question_text, q.question_type, q.points,
                       ans.selected_option_id, ans.is_correct, ans.score_awarded
                FROM lms_quiz_questions q
                LEFT JOIN lms_quiz_answers ans ON q.id = ans.question_id AND ans.attempt_id = :aid
                WHERE q.quiz_id = :qid
                ORDER BY q.order_num, q.id
            ");
            $qStmt->execute([':aid' => $attemptId, ':qid' => $attempt['quiz_id']]);
            $questions = $qStmt->fetchAll(\PDO::FETCH_ASSOC);
            
            $oStmt = $this->conn->prepare("SELECT * FROM lms_quiz_options WHERE question_id IN (SELECT id FROM lms_quiz_questions WHERE quiz_id = :qid)");
            $oStmt->execute([':qid' => $attempt['quiz_id']]);
            $options = $oStmt->fetchAll(\PDO::FETCH_ASSOC);
            
            foreach ($questions as &$q) {
                $q['options'] = array_values(array_filter($options, function($o) use ($q) {
                    return $o['question_id'] === $q['question_id'];
                }));
            }
            
            $attempt['details'] = $questions;
            return json_encode($attempt);
        } catch (\Exception $e) {
            http_response_code(500);
            return json_encode(["message" => $e->getMessage()]);
        }
    }

    public function getProgressSummary($userId)
    {
        try {
            $query = "SELECT 
                        t.event_id,
                        (SELECT COUNT(*) FROM lms_materials m2 INNER JOIN lms_topics t2 ON m2.topic_id = t2.id WHERE t2.event_id = t.event_id) as total_items,
                        (SELECT COUNT(*) FROM lms_user_progress p WHERE p.event_id = t.event_id AND p.user_id = :uid) as completed_items
                      FROM lms_topics t
                      GROUP BY t.event_id";
            
            $stmt = $this->conn->prepare($query);
            $stmt->execute([':uid' => $userId]);
            $results = $stmt->fetchAll(\PDO::FETCH_ASSOC);

            $summary = [];
            foreach ($results as $row) {
                $total = (int)$row['total_items'];
                $completed = (int)$row['completed_items'];
                $percent = $total > 0 ? round(($completed / $total) * 100) : 0;
                $summary[$row['event_id']] = $percent;
            }

            return json_encode($summary);
        } catch (\Throwable $e) {
            http_response_code(500);
            return json_encode(["message" => "Error: " . $e->getMessage()]);
        }
    }

    public function getEventProgress($eventId, $userId)
    {
        try {
            $query = "SELECT item_id FROM lms_user_progress WHERE event_id = :eid AND user_id = :uid AND is_completed = 1";
            $stmt = $this->conn->prepare($query);
            $stmt->execute([':eid' => $eventId, ':uid' => $userId]);
            $results = $stmt->fetchAll(\PDO::FETCH_ASSOC);
            
            $completedItems = array_column($results, 'item_id');
            return json_encode($completedItems);
        } catch (\Throwable $e) {
            http_response_code(500);
            return json_encode(["message" => "Error: " . $e->getMessage()]);
        }
    }

    public function getParticipantActivity($eventId, $userId)
    {
        try {
            // Materials progress
            $queryMaterials = "
                SELECT m.id, m.title, m.type, p.completed_at 
                FROM lms_materials m
                JOIN lms_topics t ON m.topic_id = t.id
                JOIN lms_user_progress p ON p.item_id = m.id 
                WHERE t.event_id = :eid AND p.user_id = :uid AND p.is_completed = 1 AND m.type != 'assignment'
                ORDER BY p.completed_at DESC
            ";
            $stmtM = $this->conn->prepare($queryMaterials);
            $stmtM->execute([':eid' => $eventId, ':uid' => $userId]);
            $materials = $stmtM->fetchAll(\PDO::FETCH_ASSOC);

            // Quizzes progress
            $queryQuizzes = "
                SELECT q.id, q.title, a.total_score as score, a.finished_at as completed_at
                FROM lms_quizzes q
                JOIN lms_topics t ON q.topic_id = t.id
                JOIN lms_quiz_attempts a ON a.quiz_id = q.id
                WHERE t.event_id = :eid AND a.user_id = :uid AND a.finished_at IS NOT NULL
                ORDER BY a.finished_at DESC
            ";
            $stmtQ = $this->conn->prepare($queryQuizzes);
            $stmtQ->execute([':eid' => $eventId, ':uid' => $userId]);
            $quizzes = $stmtQ->fetchAll(\PDO::FETCH_ASSOC);

            // Assignments progress
            $queryAssignments = "
                SELECT asg.id, asg.title, sub.score, sub.submitted_at as completed_at
                FROM lms_materials asg
                JOIN lms_topics t ON asg.topic_id = t.id
                JOIN lms_assignment_submissions sub ON sub.assignment_id = asg.id
                WHERE t.event_id = :eid AND sub.user_id = :uid AND asg.type = 'assignment'
                ORDER BY sub.submitted_at DESC
            ";
            $stmtA = $this->conn->prepare($queryAssignments);
            $stmtA->execute([':eid' => $eventId, ':uid' => $userId]);
            $assignments = $stmtA->fetchAll(\PDO::FETCH_ASSOC);

            return json_encode([
                "materials" => $materials,
                "quizzes" => $quizzes,
                "assignments" => $assignments
            ]);
        } catch (\Throwable $e) {
            http_response_code(500);
            return json_encode(["message" => "Error: " . $e->getMessage()]);
        }
    }

    public function getAllParticipantsActivity($eventId)
    {
        try {
            // Materials progress
            $queryMaterials = "
                SELECT m.id, m.title, m.type, p.completed_at, pr.nama as user_name, pr.asal_sekolah
                FROM lms_materials m
                JOIN lms_topics t ON m.topic_id = t.id
                JOIN lms_user_progress p ON p.item_id = m.id 
                JOIN event_participants ep ON ep.user_id = p.user_id AND ep.event_id = :eid
                LEFT JOIN profiles pr ON pr.id = p.user_id
                WHERE t.event_id = :eid AND p.is_completed = 1 AND m.type != 'assignment'
            ";
            $stmtM = $this->conn->prepare($queryMaterials);
            $stmtM->execute([':eid' => $eventId]);
            $materials = $stmtM->fetchAll(\PDO::FETCH_ASSOC);

            // Quizzes progress
            $queryQuizzes = "
                SELECT q.id, q.title, a.total_score as score, a.finished_at as completed_at, pr.nama as user_name, pr.asal_sekolah
                FROM lms_quizzes q
                JOIN lms_topics t ON q.topic_id = t.id
                JOIN lms_quiz_attempts a ON a.quiz_id = q.id
                JOIN event_participants ep ON ep.user_id = a.user_id AND ep.event_id = :eid
                LEFT JOIN profiles pr ON pr.id = a.user_id
                WHERE t.event_id = :eid AND a.finished_at IS NOT NULL
            ";
            $stmtQ = $this->conn->prepare($queryQuizzes);
            $stmtQ->execute([':eid' => $eventId]);
            $quizzes = $stmtQ->fetchAll(\PDO::FETCH_ASSOC);

            // Assignments progress
            $queryAssignments = "
                SELECT asg.id, asg.title, sub.score, sub.submitted_at as completed_at, pr.nama as user_name, pr.asal_sekolah
                FROM lms_materials asg
                JOIN lms_topics t ON asg.topic_id = t.id
                JOIN lms_assignment_submissions sub ON sub.assignment_id = asg.id
                JOIN event_participants ep ON ep.user_id = sub.user_id AND ep.event_id = :eid
                LEFT JOIN profiles pr ON pr.id = sub.user_id
                WHERE t.event_id = :eid AND asg.type = 'assignment'
            ";
            $stmtA = $this->conn->prepare($queryAssignments);
            $stmtA->execute([':eid' => $eventId]);
            $assignments = $stmtA->fetchAll(\PDO::FETCH_ASSOC);

            $allActivities = [];
            foreach ($materials as $m) {
                $m['_type'] = 'material';
                $allActivities[] = $m;
            }
            foreach ($quizzes as $q) {
                $q['_type'] = 'quiz';
                $allActivities[] = $q;
            }
            foreach ($assignments as $a) {
                $a['_type'] = 'assignment';
                $allActivities[] = $a;
            }

            usort($allActivities, function($a, $b) {
                $timeA = isset($a['completed_at']) && $a['completed_at'] ? strtotime($a['completed_at']) : 0;
                $timeB = isset($b['completed_at']) && $b['completed_at'] ? strtotime($b['completed_at']) : 0;
                return $timeB - $timeA;
            });

            return json_encode($allActivities);
        } catch (\Throwable $e) {
            http_response_code(500);
            return json_encode(["message" => "Error: " . $e->getMessage()]);
        }
    }

    public function getEventActivityMatrix($eventId)
    {
        try {
            // 1. Get all topics & items for columns
            $topicsStmt = $this->conn->prepare("SELECT id, title FROM lms_topics WHERE event_id = :eid ORDER BY order_num, created_at");
            $topicsStmt->execute([':eid' => $eventId]);
            $topics = $topicsStmt->fetchAll(\PDO::FETCH_ASSOC);

            $matStmt = $this->conn->prepare("SELECT id, topic_id, title, type as item_type, order_num FROM lms_materials WHERE topic_id IN (SELECT id FROM lms_topics WHERE event_id = :eid) ORDER BY order_num");
            $matStmt->execute([':eid' => $eventId]);
            $materials = $matStmt->fetchAll(\PDO::FETCH_ASSOC);

            $quizStmt = $this->conn->prepare("SELECT id, topic_id, title, 'quiz' as item_type, order_num FROM lms_quizzes WHERE topic_id IN (SELECT id FROM lms_topics WHERE event_id = :eid) ORDER BY order_num");
            $quizStmt->execute([':eid' => $eventId]);
            $quizzes = $quizStmt->fetchAll(\PDO::FETCH_ASSOC);

            $itemsByTopic = [];
            foreach ($topics as $t) {
                $itemsByTopic[$t['id']] = [];
            }
            foreach ($materials as $m) {
                $itemsByTopic[$m['topic_id']][] = $m;
            }
            foreach ($quizzes as $q) {
                $itemsByTopic[$q['topic_id']][] = $q;
            }
            // Sort items inside topic by order_num without using references
            foreach ($itemsByTopic as $tid => $items) {
                usort($items, function($a, $b) {
                    return $a['order_num'] - $b['order_num'];
                });
                $itemsByTopic[$tid] = $items;
            }

            // Combine into one ordered array of columns
            $columns = [];
            foreach ($topics as $t) {
                $tItems = $itemsByTopic[$t['id']] ?? [];
                foreach ($tItems as $item) {
                    $item['topic_title'] = $t['title'];
                    $columns[] = $item;
                }
            }

            // 2. Get participants (Rows)
            $partStmt = $this->conn->prepare("
                SELECT ep.user_id, p.nama as user_name, p.asal_sekolah 
                FROM event_participants ep 
                JOIN profiles p ON ep.user_id = p.id 
                WHERE ep.event_id = :eid AND p.role != 'Pengurus'
                ORDER BY p.nama
            ");
            $partStmt->execute([':eid' => $eventId]);
            $participants = $partStmt->fetchAll(\PDO::FETCH_ASSOC);

            // 3. Get progress
            $progStmt = $this->conn->prepare("
                SELECT user_id, item_id, is_completed, completed_at
                FROM lms_user_progress 
                WHERE item_id IN (SELECT id FROM lms_materials WHERE topic_id IN (SELECT id FROM lms_topics WHERE event_id = :eid))
            ");
            $progStmt->execute([':eid' => $eventId]);
            $progressRaw = $progStmt->fetchAll(\PDO::FETCH_ASSOC);

            $qAttemptStmt = $this->conn->prepare("
                SELECT user_id, quiz_id as item_id, MAX(total_score) as score
                FROM lms_quiz_attempts 
                WHERE quiz_id IN (SELECT id FROM lms_quizzes WHERE topic_id IN (SELECT id FROM lms_topics WHERE event_id = :eid))
                GROUP BY user_id, quiz_id
            ");
            $qAttemptStmt->execute([':eid' => $eventId]);
            $quizProgress = $qAttemptStmt->fetchAll(\PDO::FETCH_ASSOC);

            $asgStmt = $this->conn->prepare("
                SELECT sub.user_id, sub.assignment_id as item_id, sub.score
                FROM lms_assignment_submissions sub
                JOIN lms_materials m ON sub.assignment_id = m.id
                WHERE m.topic_id IN (SELECT id FROM lms_topics WHERE event_id = :eid)
            ");
            $asgStmt->execute([':eid' => $eventId]);
            $asgProgress = $asgStmt->fetchAll(\PDO::FETCH_ASSOC);

            // Structure progress: progress[user_id][item_id] = { status, score, date }
            $progress = new \stdClass();
            foreach ($participants as $p) {
                $uid = $p['user_id'];
                $progress->$uid = new \stdClass();
            }
            foreach ($progressRaw as $p) {
                $uid = $p['user_id'];
                $iid = $p['item_id'];
                if (!property_exists($progress, (string)$uid)) $progress->$uid = new \stdClass();
                $progress->$uid->$iid = ['status' => $p['is_completed'] ? 'completed' : 'pending', 'date' => $p['completed_at']];
            }
            foreach ($quizProgress as $qp) {
                $uid = $qp['user_id'];
                $iid = $qp['item_id'];
                if (!property_exists($progress, (string)$uid)) $progress->$uid = new \stdClass();
                $progress->$uid->$iid = ['status' => 'completed', 'score' => $qp['score']];
            }
            foreach ($asgProgress as $ap) {
                $uid = $ap['user_id'];
                $iid = $ap['item_id'];
                if (!property_exists($progress, (string)$uid)) $progress->$uid = new \stdClass();
                $progress->$uid->$iid = ['status' => 'completed', 'score' => $ap['score']];
            }

            return json_encode([
                "columns" => $columns,
                "participants" => $participants,
                "progress" => $progress
            ]);

        } catch (\Throwable $e) {
            http_response_code(500);
            return json_encode(["message" => "Error: " . $e->getMessage()]);
        }
    }

    public function markProgress($data, $userId)
    {
        try {
            $eventId = $data['event_id'] ?? '';
            $itemType = $data['item_type'] ?? 'material';
            $itemId = $data['item_id'] ?? '';
            
            if (!$eventId || !$itemId) {
                http_response_code(400);
                return json_encode(["message" => "Missing parameters"]);
            }

            // check if exists
            $check = $this->conn->prepare("SELECT id FROM lms_user_progress WHERE user_id = :uid AND item_type = :itype AND item_id = :iid");
            $check->execute([
                ':uid' => $userId,
                ':itype' => $itemType,
                ':iid' => $itemId
            ]);
            
            if ($check->rowCount() == 0) {
                $id = Helper::uuid();
                $ins = $this->conn->prepare("INSERT INTO lms_user_progress (id, user_id, event_id, item_type, item_id, is_completed, completed_at) VALUES (:id, :uid, :eid, :itype, :iid, 1, NOW())");
                $ins->execute([
                    ':id' => $id,
                    ':uid' => $userId,
                    ':eid' => $eventId,
                    ':itype' => $itemType,
                    ':iid' => $itemId
                ]);
            }
            return json_encode(["message" => "Progress marked"]);
        } catch (\Throwable $e) {
            http_response_code(500);
            return json_encode(["message" => "Error: " . $e->getMessage()]);
        }
    }

    private function _autoMarkProgress($itemId, $itemType, $userId) {
        try {
            $q = "SELECT t.event_id FROM lms_materials m INNER JOIN lms_topics t ON m.topic_id = t.id WHERE m.id = :id";
            $stmt = $this->conn->prepare($q);
            $stmt->execute([':id' => $itemId]);
            $row = $stmt->fetch(\PDO::FETCH_ASSOC);
            if ($row && $row['event_id']) {
                $this->markProgress([
                    'event_id' => $row['event_id'],
                    'item_type' => $itemType,
                    'item_id' => $itemId
                ], $userId);
            }
        } catch (\Throwable $e) {
            // ignore
        }
    }
// Function draft for LmsController.php
public function getEventGradebook($eventId) {
    // 1. Get all participants
    $qParts = "SELECT ep.user_id, p.nama, p.asal_sekolah, p.foto_profile 
               FROM event_participants ep 
               LEFT JOIN profiles p ON ep.user_id = p.id 
               WHERE ep.event_id = :eid AND p.role != 'Pengurus'
               ORDER BY p.nama ASC";
    $stmt = $this->conn->prepare($qParts);
    $stmt->execute([':eid' => $eventId]);
    $participants = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 2. Get all quizzes for this event
    $qQuizzes = "SELECT q.id, q.title FROM lms_quizzes q 
                 JOIN lms_topics t ON q.topic_id = t.id 
                 WHERE t.event_id = :eid ORDER BY q.order_num ASC";
    $stmt = $this->conn->prepare($qQuizzes);
    $stmt->execute([':eid' => $eventId]);
    $quizzes = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 3. Get all assignments for this event
    $qAssignments = "SELECT a.id, a.title FROM lms_materials a 
                     JOIN lms_topics t ON a.topic_id = t.id 
                     WHERE t.event_id = :eid AND a.type = 'assignment' ORDER BY a.order_num ASC";
    $stmt = $this->conn->prepare($qAssignments);
    $stmt->execute([':eid' => $eventId]);
    $assignments = $stmt->fetchAll(\PDO::FETCH_ASSOC);

    // 4. Get quiz scores (latest attempt for each user & quiz)
    // We can fetch all attempts and filter in PHP since it's simpler.
    $qQuizScores = "SELECT qa.user_id, qa.quiz_id, qa.total_score, qa.started_at 
                    FROM lms_quiz_attempts qa 
                    JOIN event_participants ep ON qa.user_id = ep.user_id AND ep.event_id = :eid
                    JOIN lms_quizzes q ON qa.quiz_id = q.id
                    JOIN lms_topics t ON q.topic_id = t.id AND t.event_id = :eid
                    ORDER BY qa.total_score DESC, qa.started_at DESC";
    $stmt = $this->conn->prepare($qQuizScores);
    $stmt->execute([':eid' => $eventId]);
    $allQuizAttempts = $stmt->fetchAll(\PDO::FETCH_ASSOC);

    // Group quiz attempts (latest only)
    $quizScores = [];
    foreach ($allQuizAttempts as $qa) {
        $key = $qa['user_id'] . '_' . $qa['quiz_id'];
        if (!isset($quizScores[$key])) {
            $quizScores[$key] = $qa['total_score'];
        }
    }

    // 5. Get assignment scores
    $qAssignmentScores = "SELECT s.user_id, s.assignment_id, s.score 
                          FROM lms_assignment_submissions s
                          JOIN lms_materials a ON s.assignment_id = a.id
                          JOIN lms_topics t ON a.topic_id = t.id
                          WHERE t.event_id = :eid AND a.type = 'assignment'";
    $stmt = $this->conn->prepare($qAssignmentScores);
    $stmt->execute([':eid' => $eventId]);
    $allAssignmentSubs = $stmt->fetchAll(\PDO::FETCH_ASSOC);

    $assignmentScores = [];
    foreach ($allAssignmentSubs as $sub) {
        $key = $sub['user_id'] . '_' . $sub['assignment_id'];
        $assignmentScores[$key] = $sub['score'];
    }

    // 6. Assemble gradebook
    $gradebook = [];
    foreach ($participants as $p) {
        $p['quizzes'] = [];
        $p['assignments'] = [];
        $totalScore = 0;
        $countItems = count($quizzes) + count($assignments);

        foreach ($quizzes as $q) {
            $score = isset($quizScores[$p['user_id'] . '_' . $q['id']]) ? floatval($quizScores[$p['user_id'] . '_' . $q['id']]) : null;
            $p['quizzes'][] = [
                'quiz_id' => $q['id'],
                'title' => $q['title'],
                'score' => $score
            ];
            if ($score !== null) {
                $totalScore += $score;
            }
        }

        foreach ($assignments as $a) {
            $score = isset($assignmentScores[$p['user_id'] . '_' . $a['id']]) ? floatval($assignmentScores[$p['user_id'] . '_' . $a['id']]) : null;
            $p['assignments'][] = [
                'assignment_id' => $a['id'],
                'title' => $a['title'],
                'score' => $score
            ];
            if ($score !== null) {
                $totalScore += $score;
            }
        }

        $p['average_score'] = $countItems > 0 ? round($totalScore / $countItems, 2) : 0;
        $gradebook[] = $p;
    }

    return json_encode([
        'quizzes' => $quizzes,
        'assignments' => $assignments,
        'participants' => $gradebook
    ]);
}

    public function getEventLeaderboard($eventId) {
        try {
            // 1. Get Participants
            $qParts = "SELECT ep.user_id, p.nama as user_name, p.asal_sekolah, p.foto_profile 
                       FROM event_participants ep 
                       JOIN profiles p ON ep.user_id = p.id 
                       WHERE ep.event_id = :eid AND p.role != 'Pengurus'
                       ORDER BY p.nama ASC";
            $stmt = $this->conn->prepare($qParts);
            $stmt->execute([':eid' => $eventId]);
            $participants = $stmt->fetchAll(\PDO::FETCH_ASSOC);

            // 2. Get Quizzes
            $qQuiz = "SELECT q.id, q.title FROM lms_quizzes q JOIN lms_topics t ON q.topic_id = t.id WHERE t.event_id = :eid";
            $stmt = $this->conn->prepare($qQuiz);
            $stmt->execute([':eid' => $eventId]);
            $quizzes = $stmt->fetchAll(\PDO::FETCH_ASSOC);

            // 3. Get Assignments
            $qAsg = "SELECT m.id, m.title, m.deadline_at FROM lms_materials m JOIN lms_topics t ON m.topic_id = t.id WHERE t.event_id = :eid AND m.type = 'assignment'";
            $stmt = $this->conn->prepare($qAsg);
            $stmt->execute([':eid' => $eventId]);
            $assignments = $stmt->fetchAll(\PDO::FETCH_ASSOC);

            // 4. Get Quiz Scores
            $qQuizScores = "SELECT qa.user_id, qa.quiz_id, qa.total_score, qa.started_at, q.title 
                            FROM lms_quiz_attempts qa 
                            JOIN lms_quizzes q ON qa.quiz_id = q.id
                            JOIN lms_topics t ON q.topic_id = t.id 
                            WHERE t.event_id = :eid
                            ORDER BY qa.total_score DESC, qa.started_at DESC";
            $stmt = $this->conn->prepare($qQuizScores);
            $stmt->execute([':eid' => $eventId]);
            $allQuizAttempts = $stmt->fetchAll(\PDO::FETCH_ASSOC);

            $quizScores = [];
            foreach ($allQuizAttempts as $qa) {
                $uid = $qa['user_id'];
                if (!isset($quizScores[$uid])) $quizScores[$uid] = [];
                // Only keep highest/latest attempt per quiz per user
                if (!isset($quizScores[$uid][$qa['quiz_id']])) {
                    $quizScores[$uid][$qa['quiz_id']] = $qa;
                }
            }

            // 5. Get Assignment Submissions
            $qAsgScores = "SELECT s.user_id, s.assignment_id, s.score, s.submitted_at, m.title, m.deadline_at
                           FROM lms_assignment_submissions s
                           JOIN lms_materials m ON s.assignment_id = m.id
                           JOIN lms_topics t ON m.topic_id = t.id
                           WHERE t.event_id = :eid AND m.type = 'assignment'";
            $stmt = $this->conn->prepare($qAsgScores);
            $stmt->execute([':eid' => $eventId]);
            $allAssignmentSubs = $stmt->fetchAll(\PDO::FETCH_ASSOC);

            $assignmentScores = [];
            foreach ($allAssignmentSubs as $sub) {
                $uid = $sub['user_id'];
                if (!isset($assignmentScores[$uid])) $assignmentScores[$uid] = [];
                $assignmentScores[$uid][$sub['assignment_id']] = $sub;
            }

            // 6. Get Attendances
            $qAtt = "SELECT user_id, attended_date, created_at FROM event_attendances WHERE event_id = :eid ORDER BY attended_date ASC";
            $stmt = $this->conn->prepare($qAtt);
            $stmt->execute([':eid' => $eventId]);
            $allAttendances = $stmt->fetchAll(\PDO::FETCH_ASSOC);

            $validUserIds = array_column($participants, 'user_id');
            $attendances = [];
            $earliestAttendancePerDay = []; // [ date => ['user_id' => uid, 'time' => timeOnly] ]

            foreach ($allAttendances as $att) {
                $uid = $att['user_id'];
                
                // Only consider valid participants (this correctly excludes Pengurus as they are excluded from $participants)
                if (!in_array($uid, $validUserIds)) continue;

                if (!isset($attendances[$uid])) $attendances[$uid] = [];
                $timeSource = !empty($att['created_at']) ? $att['created_at'] : $att['attended_date'];
                $attendances[$uid][] = $timeSource;

                $dateOnly = date('Y-m-d', strtotime($timeSource));
                $timeOnly = date('H:i:s', strtotime($timeSource));

                if ($timeOnly <= '08:00:00') {
                    if (!isset($earliestAttendancePerDay[$dateOnly]) || $timeOnly < $earliestAttendancePerDay[$dateOnly]['time']) {
                        $earliestAttendancePerDay[$dateOnly] = ['user_id' => $uid, 'time' => $timeOnly];
                    }
                }
            }

            // 7. Get LMS Grade Settings
            $stmt = $this->conn->query("SELECT grade, points FROM lms_grade_settings");
            $gradeSettingsRaw = $stmt->fetchAll(\PDO::FETCH_ASSOC);
            $gradeSettings = [];
            foreach ($gradeSettingsRaw as $gs) {
                $gradeSettings[$gs['grade']] = (int)$gs['points'];
            }
            if (empty($gradeSettings)) {
                $gradeSettings = [
                    'A' => 100,
                    'B' => 80,
                    'C' => 60,
                    'D' => 40,
                    'E' => 20
                ];
            }

            // 8. Get Activeness Grades
            $qAct = "SELECT target_user_id, grade, created_at FROM event_jury_participant_evaluations WHERE event_id = :eid";
            $stmt = $this->conn->prepare($qAct);
            $stmt->execute([':eid' => $eventId]);
            $activenessDataRaw = $stmt->fetchAll(\PDO::FETCH_ASSOC);
            $activenessData = [];
            foreach ($activenessDataRaw as $ad) {
                $activenessData[$ad['target_user_id']] = $ad;
            }

            // 9. Get Group Tasks Grades
            $qGr = "SELECT gm.user_id, je.grade, je.created_at, g.name as group_name 
                    FROM event_group_members gm 
                    JOIN event_groups g ON gm.group_id = g.id 
                    JOIN event_jury_group_evaluations je ON g.id = je.target_group_id 
                    WHERE g.event_id = :eid";
            $stmt = $this->conn->prepare($qGr);
            $stmt->execute([':eid' => $eventId]);
            $groupTaskDataRaw = $stmt->fetchAll(\PDO::FETCH_ASSOC);
            $groupTaskData = [];
            foreach ($groupTaskDataRaw as $gd) {
                $groupTaskData[$gd['user_id']] = $gd;
            }

            // 10. Get Group Likes
            $qLikes = "SELECT gm.user_id, COUNT(pe.id) as like_count 
                       FROM event_group_members gm 
                       JOIN event_groups g ON gm.group_id = g.id 
                       JOIN event_group_peer_evaluations pe ON g.id = pe.target_group_id 
                       WHERE g.event_id = :eid AND pe.evaluation = 'like'
                       GROUP BY gm.user_id";
            $stmt = $this->conn->prepare($qLikes);
            $stmt->execute([':eid' => $eventId]);
            $likesDataRaw = $stmt->fetchAll(\PDO::FETCH_ASSOC);
            $likesData = [];
            foreach ($likesDataRaw as $ld) {
                $likesData[$ld['user_id']] = (int)$ld['like_count'];
            }

            // Calculate Leaderboard
            $leaderboard = [];
            foreach ($participants as $p) {
                $uid = $p['user_id'];
                
                $totalQuizScore = 0;
                $totalAsgScore = 0;
                $onTimeBonus = 0;
                $attendanceBonus = 0;
                $activities = [];

                // Process Quizzes
                if (isset($quizScores[$uid])) {
                    foreach ($quizScores[$uid] as $qid => $qdata) {
                        $score = floatval($qdata['total_score']);
                        $totalQuizScore += $score;
                        $activities[] = [
                            'type' => 'Kuis',
                            'title' => $qdata['title'],
                            'score' => $score,
                            'date' => $qdata['started_at'],
                            'bonus' => 0
                        ];
                    }
                }

                // Process Assignments
                if (isset($assignmentScores[$uid])) {
                    foreach ($assignmentScores[$uid] as $aid => $adata) {
                        $score = floatval($adata['score']);
                        $totalAsgScore += $score;
                        
                        // Check if on time
                        $bonus = 0;
                        if ($adata['deadline_at']) {
                            $subTime = strtotime($adata['submitted_at']);
                            $deadlineTime = strtotime($adata['deadline_at']);
                            if ($subTime <= $deadlineTime) {
                                $bonus = 10;
                                $onTimeBonus += $bonus;
                            }
                        }

                        $activities[] = [
                            'type' => 'Tugas',
                            'title' => $adata['title'],
                            'score' => $score,
                            'date' => $adata['submitted_at'],
                            'bonus' => $bonus,
                            'deadline' => $adata['deadline_at']
                        ];
                    }
                }

                // Process Attendances
                $avgAttTime = null;
                $attTimes = [];
                if (isset($attendances[$uid])) {
                    $totalTimeOffset = 0;
                    foreach ($attendances[$uid] as $attDate) {
                        $timeOnly = date('H:i:s', strtotime($attDate));
                        $dateOnly = date('Y-m-d', strtotime($attDate));
                        
                        $bonusAmount = 0;
                        $titleSuffix = '';

                        // Give bonus if attendance is before 08:00 AM
                        if ($timeOnly <= '08:00:00') {
                            if (isset($earliestAttendancePerDay[$dateOnly]) && $earliestAttendancePerDay[$dateOnly]['user_id'] === $uid) {
                                $bonusAmount = 10;
                                $titleSuffix = ' (Tercepat!)';
                            } else {
                                $bonusAmount = 5;
                            }
                            $attendanceBonus += $bonusAmount;
                        }

                        $activities[] = [
                            'type' => 'Absensi',
                            'title' => 'Absensi Hari ' . date('d M Y', strtotime($attDate)) . $titleSuffix,
                            'score' => 0,
                            'date' => $attDate,
                            'bonus' => $bonusAmount
                        ];

                        // Calculate offset from 00:00:00 in seconds to find average time
                        $offset = strtotime($timeOnly) - strtotime('00:00:00');
                        $totalTimeOffset += $offset;
                        $attTimes[] = $timeOnly;
                    }
                    if (count($attendances[$uid]) > 0) {
                        $avgOffset = $totalTimeOffset / count($attendances[$uid]);
                        $avgAttTime = date('H:i:s', strtotime('00:00:00') + $avgOffset);
                    }
                }

                $activenessScore = 0;
                if (isset($activenessData[$uid])) {
                    $g = $activenessData[$uid]['grade'];
                    $activenessScore = isset($gradeSettings[$g]) ? $gradeSettings[$g] : 0;
                    $activities[] = [
                        'type' => 'Keaktifan',
                        'title' => 'Nilai Keaktifan (Grade ' . $g . ')',
                        'score' => $activenessScore,
                        'date' => $activenessData[$uid]['created_at'],
                        'bonus' => 0
                    ];
                }

                $finalTaskScore = 0;
                if (isset($groupTaskData[$uid])) {
                    $g = $groupTaskData[$uid]['grade'];
                    $finalTaskScore = isset($gradeSettings[$g]) ? $gradeSettings[$g] : 0;
                    $activities[] = [
                        'type' => 'Tugas Kelompok',
                        'title' => 'Tugas Akhir: ' . $groupTaskData[$uid]['group_name'] . ' (Grade ' . $g . ')',
                        'score' => $finalTaskScore,
                        'date' => $groupTaskData[$uid]['created_at'],
                        'bonus' => 0
                    ];
                }

                $likesBonus = 0;
                if (isset($likesData[$uid]) && $likesData[$uid] > 0) {
                    $likesBonus = $likesData[$uid]; // 1 point per like
                    $activities[] = [
                        'type' => 'Bonus Suka',
                        'title' => 'Bonus Peer Evaluation (' . $likesBonus . ' Suka)',
                        'score' => 0,
                        'date' => date('Y-m-d H:i:s'), 
                        'bonus' => $likesBonus
                    ];
                }

                $latestActivityDate = null;
                foreach ($activities as $act) {
                    if (!$latestActivityDate || strtotime($act['date']) > strtotime($latestActivityDate)) {
                        $latestActivityDate = $act['date'];
                    }
                }

                $totalScore = $totalQuizScore + $totalAsgScore + $onTimeBonus + $attendanceBonus + $activenessScore + $finalTaskScore + $likesBonus;

                $leaderboard[] = [
                    'user_id' => $uid,
                    'user_name' => $p['user_name'],
                    'asal_sekolah' => $p['asal_sekolah'],
                    'foto_profile' => $p['foto_profile'],
                    'quiz_score' => $totalQuizScore,
                    'assignment_score' => $totalAsgScore,
                    'activeness_score' => $activenessScore,
                    'final_task_score' => $finalTaskScore,
                    'on_time_bonus' => $onTimeBonus,
                    'attendance_bonus' => $attendanceBonus,
                    'likes_bonus' => $likesBonus,
                    'total_score' => $totalScore,
                    'average_attendance_time' => $avgAttTime,
                    'attendance_count' => count($attTimes),
                    'latest_activity_date' => $latestActivityDate,
                    'activities' => $activities
                ];
            }

            // Sort by total score DESC, then latest activity ASC, then avg attendance time ASC
            usort($leaderboard, function($a, $b) {
                if ($a['total_score'] == $b['total_score']) {
                    // 1. Sort by latest_activity_date ASC (earlier is better)
                    if ($a['latest_activity_date'] && $b['latest_activity_date']) {
                        $cmp = strtotime($a['latest_activity_date']) - strtotime($b['latest_activity_date']);
                        if ($cmp !== 0) return $cmp;
                    } elseif ($a['latest_activity_date']) {
                        return -1; // a has activities, b doesn't
                    } elseif ($b['latest_activity_date']) {
                        return 1;
                    }
                    
                    // 2. Fallback to average attendance time
                    if (!$a['average_attendance_time']) return 1;
                    if (!$b['average_attendance_time']) return -1;
                    return strcmp($a['average_attendance_time'], $b['average_attendance_time']);
                }
                return ($a['total_score'] > $b['total_score']) ? -1 : 1;
            });

            // Assign ranks
            foreach ($leaderboard as $idx => &$user) {
                $user['rank'] = $idx + 1;
                // sort activities by date DESC
                usort($user['activities'], function($a, $b) {
                    return strtotime($b['date']) - strtotime($a['date']);
                });
            }

            return json_encode([
                "leaderboard" => $leaderboard
            ]);

        } catch (\Throwable $e) {
            http_response_code(500);
            return json_encode(["message" => "Error: " . $e->getMessage()]);
        }
    }
}
?>
